$$$ FastScanner Version 3.0 Final By AT4RE Team $$$

[ Build Date ] : 07 - 01 - 2010

[ Signatures Date ] : 01 - 01 - 2010

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

[ Description ]

- FastScanner is a Detector for most packers, cryptors and compilers for PE Files Programmed in ASM and designed for �fast access to most needed plugins.

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

FastScanner v3.0 Final Change log:
07/01/2010

1- Update signature Database file.
2- Add Tricks Finder function in the Information dialog. [Still Beta]
3- Fixed Bug when click in the Smart-Scan button twice.
4- Fixed Bug with Overlay size.
5- Many Bug Fixed in the program.

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

FastScanner v3.0 Beta 3 Change log:
18/12/2009

1- Update and optimize signature Database file.
2- Update SmartScan method.
3- Improve the information dialog.
4- Add Overlay signature detection in the Information dialog.
5- Add number of sections detection method.
6- Add JunckCode Detection.
7- AT4RE Overlay Tool v0.2 by STRELiTZIA.
8- Hash & Crypto Detector v1.4 by Mr.Paradox.
9- Signature Manager v1.1 by GamingMasteR.
10- Fixed Bug in Smart-Scan with some protectors.
11- Fixed Bug with ToolTip when using Smart-Scan.
12- Fixed Bug when scanning a Folder.
13- Fixed Bug in the scanning algorithm.

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

FastScanner v3.0 Beta 2 Change log:
26/10/2009

1- Add colors to the disassembler by GamingMasteR.
2- Add SmartScan method.
3- Add Overlay Detection method.
4- Fixed Bug in ScanDirectory.
5- Fixed Bug in Scanning an opened file.
6- Fixed Bug with RLPack protected files.
7- Fixed Bug in Detecting Overlay.
8- Fixed Bug in Detecting Fake-Signature.
9- Fixed Bug in Matches number in the Total-Scan.

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

FastScanner v3.0 Beta Change log:
25/09/2009

1-  Change Signature DataBase for more accuracy.
2-  Updating the scanning algorithm.
3-  New and powerful Signature Manager plugin.
4-  New Hash & Crypto detector plugin by Mr.Paradox.
5-  New GFX for version 3 by RobenHoodArab.
6-  Add new PEHeader-Viewer dialog to main window in FS.
7-  Add Hex-Viewer and Resource-Viewer on the PEHeader-Viewer Dialog.
8-  Add tooltips with information about the content of PEHeader-Viewer dialog.
9-  Add Unpacking Information dialog (still Beta).
10- Add ScanDirectory dialog.
11- Add Compiler Detection Mechanism.
12- Add Anti-FakeSignature algorithm.
13- Update the Export and Import Viewer dialogs.
14- Fixed Bug in ImportTable Viewer with Upack.
15- PE Editor : Fixed Bug in Resource Viewer.
16- PE Editor : Fixed Bug in ImportTable Viewer.
17- PE Editor : Fixed Bug in ExportTable Viewer.
18- PE Editor : Add ReadOnly-Mode and FullAccess-Mode.
19- PE Editor : Add 16Edit HexEditor by yoda.
	
[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]

AT4RE TEAM [ Arab Team 4 Reverse Engineering ] @ 2010 , ALL RIGHTS RESERVED.

Web Site : www.at4re.com ....

[][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][][]
